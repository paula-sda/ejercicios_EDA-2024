#!/bin/bash
echo "Hola, vamos a ejecutar el servidor de mensajes"

cd src

python3 -u MAIN.py